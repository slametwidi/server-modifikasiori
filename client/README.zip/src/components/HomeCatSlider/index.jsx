import React from 'react'
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/navigation';

import { Navigation } from 'swiper/modules';
import { Link } from 'react-router-dom';

const HomeCatSlider = () => {
  return (
    <div className="HomeCatSlider">
        <div className="container">
            <Swiper
                slidesPerView={7.6}
                spaceBetween={15}
                navigation={true}
                modules={[Navigation]}
                className="mySwiper"
            >

                <SwiperSlide>
                    <Link>
                        <div className="item py-5 px-3 bg-white rounded-lg text-center flex flex-col justify-center items-center">
                            <img src="/card1.jpg" className="transition-all" />
                            <h3 className="text-[15px] font-[500] mt-3">Mangkok Ganda Kartel Silang</h3>
                        </div>
                    </Link>
                </SwiperSlide>

                <SwiperSlide>
                    <Link>
                        <div className="item py-5 px-3 bg-white rounded-lg text-center flex flex-col justify-center items-center">
                            <img src="/card2.jpg" />
                            <h3 className="text-[15px] font-[500] mt-3">Mangkok Ganda Kartel Lurus</h3>
                        </div>
                    </Link>
                </SwiperSlide>

                <SwiperSlide>
                    <Link>
                        <div className="item py-5 px-3 bg-white rounded-lg text-center flex flex-col justify-center items-center">
                            <img src="/card3.jpg" />
                            <h3 className="text-[15px] font-[500] mt-3">Mangkok Ganda Kartel Miring</h3>
                        </div>
                    </Link>
                </SwiperSlide>

                <SwiperSlide>
                    <Link>
                        <div className="item py-5 px-3 bg-white rounded-lg text-center flex flex-col justify-center items-center">
                            <img src="/card1.jpg" />
                            <h3 className="text-[15px] font-[500] mt-3">Mangkok Ganda Kartel Lubang</h3>
                        </div>
                    </Link>
                </SwiperSlide>

                <SwiperSlide>
                    <Link>
                        <div className="item py-5 px-3 bg-white rounded-lg text-center flex flex-col justify-center items-center">
                            <img src="/card2.jpg" />
                            <h3 className="text-[15px] font-[500] mt-3">Slamet Widi</h3>
                        </div>
                    </Link>
                </SwiperSlide>

                <SwiperSlide>
                    <Link>
                        <div className="item py-5 px-3 bg-white rounded-lg text-center flex flex-col justify-center items-center">
                            <img src="/card3.jpg" />
                            <h3 className="text-[15px] font-[500] mt-3">Slamet Widi</h3>
                        </div>
                    </Link>
                </SwiperSlide>

                <SwiperSlide>
                    <Link>
                        <div className="item py-5 px-3 bg-white rounded-lg text-center flex flex-col justify-center items-center">
                            <img src="/card1.jpg" />
                            <h3 className="text-[15px] font-[500] mt-3">Slamet Widi</h3>
                        </div>
                    </Link>
                </SwiperSlide>

                <SwiperSlide>
                    <Link>
                        <div className="item py-5 px-3 bg-white rounded-lg text-center flex flex-col justify-center items-center">
                            <img src="/card2.jpg" />
                            <h3 className="text-[15px] font-[500] mt-3">Slamet Widi</h3>
                        </div>
                    </Link>
                </SwiperSlide>

                <SwiperSlide>
                    <Link>
                        <div className="item py-5 px-3 bg-white rounded-lg text-center flex flex-col justify-center items-center">
                            <img src="https://down-id.img.susercontent.com/file/id-11134207-7r98v-lonwu2h0vllv6f_tn.webp" />
                            <h3 className="text-[15px] font-[500] mt-3">Slamet Widi</h3>
                        </div>
                    </Link>
                </SwiperSlide>

            </Swiper>
        </div>
    </div>
  )
}

export default HomeCatSlider;
