import Button from '@mui/material/Button';
import React, { useState } from 'react'
import { RiMenu2Fill } from "react-icons/ri";
import { LiaAngleDownSolid } from "react-icons/lia";
import { Link } from 'react-router-dom';
import { MdDeliveryDining } from "react-icons/md";
import CategoryPanel from './CategoryPanel';
import { FaCaretRight } from "react-icons/fa";

import "../Navigation/style.css"

const Navigation = () => {

    const [isOpenCatPanel, setIsOpenCatPanel] = useState(false);

    const openCategoryPanel=()=>{
        setIsOpenCatPanel(true);
    }

  return (
    <>
            <nav className="py-2">
        <div className="container flex items-center justify-end gap-8">
            <div className="col_1 w-[20%]">
                <Button className="!text-black gap-2 w-full" onClick={openCategoryPanel}>
                    <RiMenu2Fill className="text-[18px]"/>
                    Shop By Categories
                    <LiaAngleDownSolid className="text-[13px] ml-auto font-bold" />
                </Button>
            </div>

            <div className="col_2 w-[65%]">
                <ul className="flex items-center gap-7 nav">
                    <li className="list-none">
                        <Link to="/" className="link transition text-[14px] font-[500]">
                            <Button className="link transition !font-[500]">
                                Home
                            </Button>
                        </Link>
                    </li>

                    <li className="list-none relative">
                        <Link to="/" className="link transition font-[500]">
                            <Button className="link transition !font-[500] !text-[12px]">
                                X1 Racing
                            </Button>
                        </Link>

                        <div className="submenu absolute top-[120%] left-[0%] min-w-[300px] bg-white shadow-md opacity-0 transition-all">
                            <ul>
                                <li className="list-none relative">
                                    <Link to="/" className="flex items-center relative flex-col w-full">
                                    <Button className="flex !justify-between items-center text-[rgba(0,0,0,0.9)] w-full !text-left !rounded-none">Rokok <FaCaretRight /></Button>

                                    <div className="submenu absolute top-[0%] left-[100%] min-w-[300px] bg-white shadow-md opacity-0 transition-all">
                                        <ul>
                                            <li className="list-none w-full">
                                                <Link to="/" className="w-full">
                                                <Button className="text-[rgba(0,0,0,0.9)] w-full !text-left !justify-start !rounded-none">Garpit</Button>
                                                </Link>
                                            </li>
                                            <li className="list-none w-full">
                                                <Link to="/" className="w-full">
                                                <Button className="text-[rgba(0,0,0,0.9)] w-full !text-left !justify-start !rounded-none">Magnum</Button>
                                                </Link>
                                            </li>
                                            <li className="list-none w-full">
                                                <Link to="/" className="w-full">
                                                <Button className="text-[rgba(0,0,0,0.9)] w-full !text-left !justify-start !rounded-none">Neslite</Button>
                                                </Link>
                                            </li>
                                            <li className="list-none w-full">
                                                <Link to="/" className="w-full">
                                                <Button className="text-[rgba(0,0,0,0.9)] w-full !text-left !justify-start !rounded-none">Sampurna</Button>
                                                </Link>
                                            </li>
                                        </ul>
                                    </div>
                                    </Link>
                                </li>
                                <li className="list-none w-full relative">
                                    <Link to="/" className="w-full">
                                    <Button className="flex !justify-between items-center text-[rgba(0,0,0,0.9)] w-full !text-left !rounded-none">Kopi <FaCaretRight /></Button>
                                    <div className="submenu absolute top-[0%] left-[100%] min-w-[300px] bg-white shadow-md opacity-0 transition-all">
                                        <ul>
                                            <li className="list-none w-full">
                                                <Link to="/" className="w-full">
                                                <Button className="text-[rgba(0,0,0,0.9)] w-full !text-left !justify-start !rounded-none">Luwak White</Button>
                                                </Link>
                                            </li>
                                            <li className="list-none w-full">
                                                <Link to="/" className="w-full">
                                                <Button className="text-[rgba(0,0,0,0.9)] w-full !text-left !justify-start !rounded-none">God Day</Button>
                                                </Link>
                                            </li>
                                            <li className="list-none w-full">
                                                <Link to="/" className="w-full">
                                                <Button className="text-[rgba(0,0,0,0.9)] w-full !text-left !justify-start !rounded-none">Nescafe</Button>
                                                </Link>
                                            </li>
                                        </ul>
                                    </div>
                                    </Link>
                                </li>
                                <li className="list-none w-full">
                                    <Link to="/" className="w-full">
                                    <Button className="text-[rgba(0,0,0,0.9)] w-full !text-left !justify-start !rounded-none">Gorengan</Button>
                                    </Link>
                                </li>
                                <li className="list-none w-full">
                                    <Link to="/" className="w-full">
                                    <Button className="text-[rgba(0,0,0,0.9)] w-full !text-left !justify-start !rounded-none">Doclang</Button>
                                    </Link>
                                </li>
                            </ul>
                        </div>

                    </li>

                    <li className="list-none relative">
                        <Link to="/" className="link transition text-[10px] font-[500]">
                            <Button className="link transition !font-[500] !text-[11px]">
                                Mangkok Ganda Custom
                            </Button>
                        </Link>

                        <div className="submenu absolute top-[120%] left-[0%] min-w-[300px] bg-white shadow-md opacity-0 transition-all">
                            <ul>
                                <li className="list-none w-full">
                                    <Button className="text-[rgba(0,0,0,0.9)] w-full !text-left !justify-start !rounded-none">Karbu</Button>
                                </li>
                                <li className="list-none w-full">
                                    <Button className="text-[rgba(0,0,0,0.9)] w-full !text-left !justify-start !rounded-none">FI</Button>
                                </li>
                                <li className="list-none w-full">
                                    <Button className="text-[rgba(0,0,0,0.9)] w-full !text-left !justify-start !rounded-none">Magnum</Button>
                                </li>
                                <li className="list-none w-full">
                                    <Button className="text-[rgba(0,0,0,0.9)] w-full !text-left !justify-start !rounded-none">Garpit</Button>
                                </li>
                            </ul>
                        </div>
                    </li>

                    <li className="list-none">
                        <Link to="/" className="link transition text-[10px] font-[500]">
                            <Button className="link transition !font-[500] !text-[12px]">
                                Pulley Bubut Custom
                            </Button>
                        </Link>
                    </li>

                    <li className="list-none">
                        <Link to="/" className="link transition text-[10px] font-[500]">
                            <Button className="link transition !font-[500] !text-[12px]">
                                Mangkok Kartel
                            </Button>
                        </Link>
                    </li>

                    <li className="list-none">
                        <Link to="/" className="link transition text-[10px] font-[500]">
                            <Button className="link transition !font-[500] !text-[12px]">
                                Filter Udara Racing
                            </Button>
                        </Link>
                    </li>

                    <li className="list-none">
                        <Link to="/" className="link transition text-[10px] font-[500]">
                            <Button className="link transition !font-[500] !text-[12px]">
                                Aksesoris
                            </Button>
                        </Link>
                    </li>
                </ul>
            </div>

            <div className="col_2 w-[15%]">
            <p className="text-[13px] font-[500] flex items-center gap-1 mb-0 mt-0">
                <MdDeliveryDining className="text-[20px]" />
                Gratis Ongkir Seluruh Indonesia!
            </p>
            </div>

        </div>
    </nav>
    
    <CategoryPanel isOpenCatPanel={isOpenCatPanel} setIsOpenCatPanel={setIsOpenCatPanel}/>
    </>
  );
};

export default Navigation;
