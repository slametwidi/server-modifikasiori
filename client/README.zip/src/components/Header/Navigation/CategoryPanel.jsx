import React, {useState} from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import Button from '@mui/material/Button';
import { IoClose } from "react-icons/io5";
import { FaChevronDown } from "react-icons/fa";
import { Link } from 'react-router-dom';
import { FaChevronUp } from "react-icons/fa";

const CategoryPanel = (props) => {

    const [submenuIndex, setSubmenuIndex] = useState (null);
    const [InnerSubmenuIndex, setInnerSubmenuIndex] = useState (null);

    const togglerDrawer = (newOpen) => () => {
        props.setIsOpenCatPanel(newOpen);
    };

    const openSubmenu = (index)=>{
        if(submenuIndex===index){
            setSubmenuIndex(null);
        }else{
            setSubmenuIndex(index);
        }
    }

    const openInnerSubmenu = (index)=>{
        if(InnerSubmenuIndex===index){
            setInnerSubmenuIndex(null);
        }else{
            setInnerSubmenuIndex(index);
        }
    }

    const DrawerList = (
    <Box sx={{ width: 250 }} role="presentation" className="categoryPanel">

        <div>
            <img className="p-5 flex items-center w-full" src="/logo.png" />
        </div>

        <h3 className="p-5 text-[18px] font-[900] flex items-center justify-between cursor-pointer">
            Shop By Categories <IoClose onClick={togglerDrawer(false)} className="cursor-pointer text-[20px]"/>
        </h3>

        <div className="scroll">
            <ul className="w-full">
                <li className="list-none flex items-center relative flex-col">
                    <Link to="/" className="w-full">
                    <Button className="w-full !text-left !justify-start !px-3 !text-[rgba(0,0,0,0.7)] !text-[13px]">Mangkok Ganda Custom</Button>
                    </Link>

                    {
                        submenuIndex === 0 ? (
                    <FaChevronDown className="absolute top-[10px] right-[15px]" onClick={()=>openSubmenu(0)} />
                    ) : (
                        <FaChevronUp className="absolute top-[10px] right-[15px]" onClick={()=>openSubmenu(0)} />
                    )
                    }

                    {
                        submenuIndex===0 && (
                            <ul className="submenu w-full pl-3">
                                <li className="list-none relative flex-col">
                                <Link to="/" className="w-full">
                                <Button className="w-full !text-left !justify-start !px-3 !text-[rgba(0,0,0,0.7)]">Beat</Button>
                                </Link>

                                {
                                    InnerSubmenuIndex === 0 ? (
                                <FaChevronDown className="absolute top-[10px] right-[15px]" onClick={()=>openInnerSubmenu(0)} />
                                ) : (
                                    <FaChevronUp className="absolute top-[10px] right-[15px]" onClick={()=>openInnerSubmenu(0)} />
                                )
                                }

                                {
                                    InnerSubmenuIndex===0 && (
                                        <ul className="inner_submenu w-full pl-3">
                                <li className="list-none relative mb-1">
                                    <Link to="/" className="link w-full !text-left !justify-start !px-3 transition text-[14px]">X1 Racing</Link>
                                </li>
                                <li className="list-none relative mb-1">
                                    <Link to="/" className="link w-full !text-left !justify-start !px-3 transition text-[14px]">Daytona</Link>
                                </li>
                                </ul>
                                    )
                                }
                        </li>
                    </ul>
                    )
                    }

                    {
                        submenuIndex===1 && (
                            <ul className="submenu w-full pl-3">
                                <li className="list-none relative flex-col">
                                <Link to="/" className="w-full">
                                <Button className="w-full !text-left !justify-start !px-3 !text-[rgba(0,0,0,0.7)]">Beat</Button>
                                </Link>

                                {
                                    InnerSubmenuIndex === 0 ? (
                                <FaChevronDown className="absolute top-[10px] right-[15px]" onClick={()=>openInnerSubmenu(1)} />
                                ) : (
                                    <FaChevronUp className="absolute top-[10px] right-[15px]" onClick={()=>openInnerSubmenu(1)} />
                                )
                                }

                                {
                                    InnerSubmenuIndex===1 && (
                                        <ul className="inner_submenu w-full pl-3">
                                <li className="list-none relative mb-1">
                                    <Link to="/" className="link w-full !text-left !justify-start !px-3 transition text-[14px]">X1 Racing</Link>
                                </li>
                                <li className="list-none relative mb-1">
                                    <Link to="/" className="link w-full !text-left !justify-start !px-3 transition text-[14px]">Daytona</Link>
                                </li>
                                </ul>
                                    )
                                }
                        </li>
                    </ul>
                    )
                    }

                    
                </li>

                <li className="list-none flex items-center relative flex-col">
                    <Link to="/" className="w-full">
                    <Button className="w-full !text-left !justify-start !px-3 !text-[rgba(0,0,0,0.7)] !text-[13px]">Pully Bubut Custom</Button>
                    </Link>

                    {
                        submenuIndex === 1 ? (
                    <FaChevronDown className="absolute top-[10px] right-[15px]" onClick={()=>openSubmenu(1)} />
                    ) : (
                        <FaChevronUp className="absolute top-[10px] right-[15px]" onClick={()=>openSubmenu(1)} />
                    )
                    }

                    {
                        submenuIndex===1 && (
                            <ul className="submenu w-full pl-3">
                                <li className="list-none relative flex-col">
                                <Link to="/" className="w-full">
                                <Button className="w-full !text-left !justify-start !px-3 !text-[rgba(0,0,0,0.7)]">Beat</Button>
                                </Link>

                                {
                                    InnerSubmenuIndex === 1 ? (
                                <FaChevronDown className="absolute top-[10px] right-[15px]" onClick={()=>openInnerSubmenu(1)} />
                                ) : (
                                    <FaChevronUp className="absolute top-[10px] right-[15px]" onClick={()=>openInnerSubmenu(1)} />
                                )
                                }

                                {
                                    InnerSubmenuIndex===1 && (
                                        <ul className="inner_submenu absolute top-[100%] left-[0%] w-full pl-3">
                                <li className="list-none relative mb-1">
                                    <Link to="/" className="link w-full !text-left !justify-start !px-3 transition text-[14px]">X1 Racing</Link>
                                </li>
                                <li className="list-none relative mb-1">
                                    <Link to="/" className="link w-full !text-left !justify-start !px-3 transition text-[14px]">Daytona</Link>
                                </li>
                                </ul>
                                    )
                                }
                        </li>
                    </ul>
                    )
                    }

                    
                </li>
            </ul>
        </div>
    </Box>
  );

  return (
    <>
      <Drawer open={props.isOpenCatPanel} onClose={togglerDrawer(false)}>
        {DrawerList}
      </Drawer>
    </>
  )
}

export default CategoryPanel;
